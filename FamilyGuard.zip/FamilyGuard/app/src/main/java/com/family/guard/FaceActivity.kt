package com.family.guard

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions

/**
 * Face step: one face must be visible and blink (live check).
 * NOTE: this proves "a live face is present", not "which person". To match a specific enrolled
 * face, plug a TFLite face-embedding model in at onLive() (see README).
 */
class FaceActivity : AppCompatActivity() {
    private var state = 0
    private lateinit var pv: PreviewView
    private lateinit var msg: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pv = PreviewView(this)
        msg = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); setBackgroundColor(0x99000000.toInt())
            gravity = Gravity.CENTER; setPadding(24, 24, 24, 24); text = "Look at the camera"
        }
        val root = FrameLayout(this)
        root.addView(pv)
        root.addView(msg, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start()
        else requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) start()
        else { setResult(RESULT_CANCELED); finish() }
    }

    private fun start() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val provider = fut.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            val det = FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build()
            )
            val an = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            an.setAnalyzer(ContextCompat.getMainExecutor(this)) { proxy ->
                val img = proxy.image
                if (img == null) { proxy.close(); return@setAnalyzer }
                det.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                    .addOnSuccessListener { handle(it) }
                    .addOnCompleteListener { proxy.close() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, an)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handle(faces: List<Face>) {
        if (state >= 3) return
        if (faces.size != 1) { msg.text = "Show one face to the camera"; return }
        val f = faces[0]
        val l = f.leftEyeOpenProbability ?: return
        val r = f.rightEyeOpenProbability ?: return
        val open = minOf(l, r) > 0.7f
        val closed = maxOf(l, r) < 0.3f
        when (state) {
            0 -> if (open) { state = 1; msg.text = "Now blink" }
            1 -> if (closed) state = 2
            2 -> if (open) { state = 3; onLive() }
        }
    }

    private fun onLive() { setResult(RESULT_OK); finish() }
}

package com.family.guard

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

object Enforcer {
    /** Enforcement is ON only when NOT charging and no admin override is active. */
    fun enforcing(c: Context) = !Charge.isCharging(c) && System.currentTimeMillis() >= Store.overrideUntil(c)

    fun isOwner(c: Context) =
        (c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isDeviceOwnerApp(c.packageName)

    /** Device Owner mode only: suspend blocked apps + block their uninstall while enforcing. */
    fun sync(c: Context) {
        if (!isOwner(c)) return
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(c, AdminReceiver::class.java)
        val want = if (enforcing(c)) Store.blocked(c) else emptySet()
        val applied = Store.applied(c)
        if (want == applied) return
        try {
            (applied - want).let { off ->
                if (off.isNotEmpty()) {
                    dpm.setPackagesSuspended(admin, off.toTypedArray(), false)
                    off.forEach { dpm.setUninstallBlocked(admin, it, false) }
                }
            }
            (want - applied).let { on ->
                if (on.isNotEmpty()) {
                    dpm.setPackagesSuspended(admin, on.toTypedArray(), true)
                    on.forEach { dpm.setUninstallBlocked(admin, it, true) }
                }
            }
            Store.setApplied(c, want)
        } catch (_: Exception) {}
    }
}

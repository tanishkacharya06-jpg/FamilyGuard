package com.family.guard

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.security.MessageDigest
import java.time.LocalDate

object Store {
    private fun p(c: Context) = c.getSharedPreferences("guard", Context.MODE_PRIVATE)
    fun hash(s: String): String = MessageDigest.getInstance("SHA-256")
        .digest("fg:$s".toByteArray()).joinToString("") { "%02x".format(it) }

    // admin
    fun adminPassSet(c: Context) = p(c).contains("adminHash")
    fun setAdminPass(c: Context, s: String) = p(c).edit().putString("adminHash", hash(s)).apply()
    fun checkAdmin(c: Context, s: String) = p(c).getString("adminHash", null) == hash(s)

    // users (1 or 2)
    fun userCount(c: Context) = p(c).getInt("userCount", 1)
    fun setUserCount(c: Context, n: Int) = p(c).edit().putInt("userCount", n).apply()
    fun name(c: Context, i: Int) = p(c).getString("name$i", "User $i")!!
    fun setName(c: Context, i: Int, s: String) = p(c).edit().putString("name$i", s).apply()
    fun limitMin(c: Context, i: Int) = p(c).getInt("limit$i", 120)
    fun setLimit(c: Context, i: Int, m: Int) = p(c).edit().putInt("limit$i", m).apply()
    fun userPassSet(c: Context, i: Int) = p(c).contains("pass$i")
    fun setUserPass(c: Context, i: Int, s: String) = p(c).edit().putString("pass$i", hash(s)).apply()
    fun checkUserPass(c: Context, i: Int, s: String) = p(c).getString("pass$i", null) == hash(s)

    // daily usage (resets each day)
    fun usedMs(c: Context, i: Int): Long {
        if (p(c).getString("day$i", "") != LocalDate.now().toString()) return 0L
        return p(c).getLong("used$i", 0L)
    }
    fun addUsed(c: Context, i: Int, ms: Long) {
        val v = usedMs(c, i) + ms
        p(c).edit().putString("day$i", LocalDate.now().toString()).putLong("used$i", v).apply()
    }

    // blocked apps
    fun blocked(c: Context): Set<String> = p(c).getStringSet("blocked", emptySet())!!.toSet()
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", s).apply()
    fun applied(c: Context): Set<String> = p(c).getStringSet("applied", emptySet())!!.toSet()
    fun setApplied(c: Context, s: Set<String>) = p(c).edit().putStringSet("applied", s).apply()

    // session + override
    fun session(c: Context) = p(c).getInt("session", 0)
    fun setSession(c: Context, i: Int) = p(c).edit().putInt("session", i).apply()
    fun lastOff(c: Context) = p(c).getLong("lastOff", 0L)
    fun setLastOff(c: Context, t: Long) = p(c).edit().putLong("lastOff", t).apply()
    fun overrideUntil(c: Context) = p(c).getLong("override", 0L)
    fun setOverrideUntil(c: Context, t: Long) = p(c).edit().putLong("override", t).apply()
}

object Charge {
    fun isCharging(c: Context): Boolean {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
    }
}

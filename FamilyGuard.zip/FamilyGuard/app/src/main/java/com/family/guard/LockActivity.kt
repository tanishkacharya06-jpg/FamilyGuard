package com.family.guard

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : AppCompatActivity() {
    companion object {
        @Volatile var showing = false
        @Volatile var reason = ""
    }

    private var picked = 1

    private val faceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) fingerprintStep() else Ui.toast(this, "Face check failed")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        build(intent.getStringExtra("reason") ?: "login")
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        build(i.getStringExtra("reason") ?: "login")
    }

    override fun onResume() { super.onResume(); showing = true }
    override fun onStop() { super.onStop(); showing = false }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (reason != "login") goHome() }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun build(r: String) {
        reason = r
        val title = when (r) {
            "blocked" -> "This app is blocked"
            "timeup" -> "Time limit reached"
            "admin" -> "Admin only"
            else -> "Who is using this phone?"
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#111827")); setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply { text = title; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        if (r == "login") root.addView(btn("Log in") { startLogin() })
        else root.addView(btn("Go home") { goHome() })
        root.addView(btn("Phone / Emergency call") {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        root.addView(btn("Admin override (15 min)") {
            Ui.askAdmin(this, {
                Store.setOverrideUntil(this, System.currentTimeMillis() + 15 * 60_000)
                Enforcer.sync(this); finish()
            })
        })
        setContentView(root)
    }

    // ---- login: choose user -> face -> fingerprint -> password ----
    private fun startLogin() {
        val n = Store.userCount(this)
        if (n == 1) { picked = 1; faceLauncher.launch(Intent(this, FaceActivity::class.java)); return }
        val names = Array(n) { Store.name(this, it + 1) }
        AlertDialog.Builder(this).setTitle("Which user are you?").setItems(names) { _, which ->
            picked = which + 1
            faceLauncher.launch(Intent(this, FaceActivity::class.java))
        }.show()
    }

    private fun fingerprintStep() {
        val ok = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (ok != BiometricManager.BIOMETRIC_SUCCESS) {
            Ui.toast(this, "No fingerprint enrolled - step skipped"); passwordStep(); return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { passwordStep() }
                override fun onAuthenticationError(code: Int, s: CharSequence) { Ui.toast(this@LockActivity, "Fingerprint cancelled") }
            })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Fingerprint")
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).build())
    }

    private fun passwordStep() {
        if (!Store.userPassSet(this, picked)) { done(); return }
        Ui.passDialog(this, "Password for ${Store.name(this, picked)}", {
            if (Store.checkUserPass(this, picked, it)) done()
            else { Ui.toast(this, "Wrong password"); passwordStep() }
        })
    }

    private fun done() {
        Store.setSession(this, picked)
        finish()
    }
}

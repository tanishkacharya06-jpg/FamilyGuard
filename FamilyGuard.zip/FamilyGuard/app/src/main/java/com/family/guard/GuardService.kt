package com.family.guard

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

class GuardService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var lastTick = 0L
    private var lastLock = 0L
    private var fg = ""

    private val tick = object : Runnable {
        override fun run() { onTick(); h.postDelayed(this, 5000) }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> Store.setLastOff(c, System.currentTimeMillis())
                Intent.ACTION_SCREEN_ON -> {
                    if (System.currentTimeMillis() - Store.lastOff(c) > 5 * 60_000) Store.setSession(c, 0)
                    if (Enforcer.enforcing(c) && Store.session(c) == 0) lock("login")
                }
                Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED -> Enforcer.sync(c)
            }
        }
    }

    override fun onServiceConnected() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(rx, f)
        Enforcer.sync(this)
        h.post(tick)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { unregisterReceiver(rx) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onInterrupt() {}

    private fun lock(reason: String) {
        val now = SystemClock.elapsedRealtime()
        if (LockActivity.showing && LockActivity.reason == reason) return
        if (now - lastLock < 800) return
        lastLock = now
        startActivity(Intent(this, LockActivity::class.java).putExtra("reason", reason)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    private fun whitelisted(pkg: String): Boolean {
        val home = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        ).any { it.activityInfo.packageName == pkg }
        val dialer = (getSystemService(TELECOM_SERVICE) as TelecomManager).defaultDialerPackage == pkg
        val ime = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.any { it.packageName == pkg }
        return home || dialer || ime || pkg.contains("emergency")
    }

    private fun label(pkg: String) = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun screenHas(text: String) =
        rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.isNotEmpty() == true

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        val isSettings = pkg.contains("settings")
        val isInstaller = pkg.contains("packageinstaller")
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && !isSettings && !isInstaller) return
        if (!Enforcer.enforcing(this)) return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return

        if (pkg in Store.blocked(this)) { lock("blocked"); return }

        if (isSettings && screenHas("Family Guard")) { lock("admin"); return }   // protects admin/accessibility/app-info pages
        if (isInstaller) {                                                       // protects uninstall dialogs
            val names = Store.blocked(this).map { label(it) } + "Family Guard"
            if (names.any { screenHas(it) }) { performGlobalAction(GLOBAL_ACTION_BACK); lock("blocked"); return }
        }

        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (whitelisted(pkg)) return
        fg = pkg
        val u = Store.session(this)
        if (u == 0) { lock("login"); return }
        if (Store.usedMs(this, u) >= Store.limitMin(this, u) * 60_000L) lock("timeup")
    }

    private fun onTick() {
        Enforcer.sync(this)
        if (!Enforcer.enforcing(this)) { lastTick = 0; return }
        if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) { lastTick = 0; return }
        val u = Store.session(this)
        if (u == 0) { lastTick = 0; lock("login"); return }
        val now = SystemClock.elapsedRealtime()
        if (lastTick != 0L) Store.addUsed(this, u, now - lastTick)
        lastTick = now
        if (Store.usedMs(this, u) >= Store.limitMin(this, u) * 60_000L && fg.isNotEmpty() && !whitelisted(fg)) lock("timeup")
    }
}

# Family Guard

Admin-controlled app blocker + per-user time limits + face / fingerprint / password login.
**Enforcement only runs while the charger is NOT connected** - plug in a charger and everything stops instantly.

## Build the APK
**Android Studio:** File > Open this folder > wait for Gradle sync > Build > Build APK(s).
**No PC? GitHub:** upload this folder to a new repo > Actions > "Build APK" > Run workflow > download artifact `FamilyGuard-apk`.
(Signed with the debug key so it installs directly. This project has not been compiled in the chat sandbox - if Gradle reports an error, send it to Claude and it will be fixed.)

## First-time setup
1. Install the APK, open **Family Guard**, create the **admin passcode** (the app asks for it every time it is opened).
2. Tap **Activate device admin** and **Enable accessibility service** (turn on "Family Guard"). Android will show a restricted-setting warning on newer versions: App info > top-right menu > "Allow restricted settings".
3. Choose 1 or 2 users, names, daily limit in minutes, user passwords; tick the apps to block; **SAVE**.
4. Optional hard mode (blocked apps are truly suspended and can't be uninstalled): remove all accounts from the phone, enable USB debugging, then
   `adb shell dpm set-device-owner com.family.guard/.AdminReceiver`

## If you get locked out (recovery)
1. **Plug in a charger** - all blocking and limits switch off immediately. Go to Settings and change anything you want.
2. On any lock screen press **Admin override (15 min)** and enter the admin passcode.
3. Opening the Family Guard icon (admin passcode) gives 10 free minutes.
4. **Safe mode** (hold power-off > long-press > Safe mode): third-party accessibility services are disabled, so you can remove device admin and uninstall.
5. Device Owner mode only: uninstall is blocked by Android. For an easy exit add `android:testOnly="true"` to the `<application>` tag, install with `adb install -t`, and later run `adb shell dpm remove-active-admin com.family.guard/.AdminReceiver`. Without that, the last resort is a factory reset.
6. Forgot the admin passcode: use 1, 4 or 5.
The Phone dialer and emergency calls are never blocked.

## How it behaves
- Phone locked behind login after the screen has been off 5+ minutes: pick user (if 2) > face blink check > fingerprint > password.
- Time is counted per user while the screen is on and the charger is off; when the limit is reached a lock screen covers every app except dialer/launcher/keyboard.
- Without Device Owner: blocked apps are covered by a lock screen the moment they open, and uninstall dialogs and the Settings pages of Family Guard are bounced back. Other uninstall routes (e.g. Play Store) are not intercepted.

## Known limits
- Face step = live face + blink (ML Kit). It does not identify *which* face. To match a person, add a TFLite face-embedding model in `FaceActivity.onLive()`.
- Fingerprint uses Android's biometric prompt (any enrolled fingerprint of the phone). If none is enrolled the step is skipped so you can't brick the phone.
- Plugging in a charger disables protection by design - anyone can do it.

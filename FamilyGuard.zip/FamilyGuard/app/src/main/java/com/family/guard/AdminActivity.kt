package com.family.guard

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AdminActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Store.adminPassSet(this)) setup()
        else Ui.askAdmin(this, {
            // opening the admin panel gives the admin 10 free minutes (e.g. to change Settings)
            Store.setOverrideUntil(this, System.currentTimeMillis() + 10 * 60_000)
            Enforcer.sync(this); show()
        }, { finish() })
    }

    private fun setup() = Ui.passDialog(this, "Create admin passcode (min 4 characters)", {
        if (it.length >= 4) { Store.setAdminPass(this, it); show() }
        else { Ui.toast(this, "Too short"); setup() }
    }, { finish() })

    private fun a11yOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains(packageName) == true

    private fun show() {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, AdminReceiver::class.java)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; val p = Ui.dp(this@AdminActivity, 16); setPadding(p, p, p, p)
        }
        setContentView(ScrollView(this).apply { addView(col) })

        fun head(t: String) = col.addView(TextView(this).apply { text = t; textSize = 18f; setTextColor(Color.BLACK); setPadding(0, 32, 0, 8) })
        fun btn(t: String, f: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
            this.hint = hint; setText(value); inputType = type
        }.also { col.addView(it) }

        head("Status")
        val status = TextView(this)
        fun refresh() {
            status.text = "Device admin: ${dpm.isAdminActive(admin)}\nAccessibility service: ${a11yOn()}\nDevice owner (hard block): ${dpm.isDeviceOwnerApp(packageName)}"
        }
        refresh(); col.addView(status)
        btn("1. Activate device admin") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Stops Family Guard from being uninstalled."))
        }
        btn("2. Enable accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("Refresh status") { refresh() }
        btn("Change admin passcode") {
            Ui.passDialog(this, "New admin passcode", { if (it.length >= 4) Store.setAdminPass(this, it) else Ui.toast(this, "Too short") })
        }

        head("Users")
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val r1 = RadioButton(this).apply { text = "1 user"; id = 1 }
        val r2 = RadioButton(this).apply { text = "2 users"; id = 2 }
        rg.addView(r1); rg.addView(r2); col.addView(rg)
        val names = arrayOfNulls<EditText>(3); val limits = arrayOfNulls<EditText>(3); val passes = arrayOfNulls<EditText>(3)
        val boxes = arrayOfNulls<LinearLayout>(3)
        for (i in 1..2) {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(box); boxes[i] = box
            box.addView(TextView(this).apply { text = "User $i"; setTextColor(Color.DKGRAY); setPadding(0, 16, 0, 0) })
            names[i] = EditText(this).apply { hint = "Name"; setText(Store.name(this@AdminActivity, i)) }.also { box.addView(it) }
            limits[i] = EditText(this).apply {
                hint = "Daily limit (minutes)"; inputType = InputType.TYPE_CLASS_NUMBER
                setText(Store.limitMin(this@AdminActivity, i).toString())
            }.also { box.addView(it) }
            passes[i] = EditText(this).apply {
                hint = if (Store.userPassSet(this@AdminActivity, i)) "Password (blank = keep current)" else "Set password"
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }.also { box.addView(it) }
        }
        fun layout(n: Int) { boxes[2]!!.visibility = if (n == 2) View.VISIBLE else View.GONE }
        rg.check(Store.userCount(this)); layout(Store.userCount(this))
        rg.setOnCheckedChangeListener { _, id -> layout(id) }

        head("Blocked apps")
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName }.distinct().filter { it != packageName }
            .sortedBy { pm.getApplicationLabel(pm.getApplicationInfo(it, 0)).toString().lowercase() }
        val blocked = Store.blocked(this)
        val checks = apps.map { pkg ->
            CheckBox(this).apply {
                text = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                isChecked = pkg in blocked
            }.also { col.addView(it) } to pkg
        }

        btn("SAVE") {
            val n = rg.checkedRadioButtonId.coerceIn(1, 2)
            Store.setUserCount(this, n)
            for (i in 1..n) {
                Store.setName(this, i, names[i]!!.text.toString().ifBlank { "User $i" })
                Store.setLimit(this, i, limits[i]!!.text.toString().toIntOrNull() ?: 120)
                val pw = passes[i]!!.text.toString()
                if (pw.isNotEmpty()) Store.setUserPass(this, i, pw)
            }
            Store.setBlocked(this, checks.filter { it.first.isChecked }.map { it.second }.toSet())
            Enforcer.sync(this)
            Ui.toast(this, "Saved")
        }
    }
}

package com.family.guard

import android.app.Activity
import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object Ui {
    fun dp(c: Context, n: Int) = (n * c.resources.displayMetrics.density).toInt()
    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

    fun passDialog(a: Activity, title: String, onOk: (String) -> Unit, onCancel: () -> Unit = {}) {
        val e = EditText(a)
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        AlertDialog.Builder(a).setTitle(title).setView(e).setCancelable(false)
            .setPositiveButton("OK") { _, _ -> onOk(e.text.toString()) }
            .setNegativeButton("Cancel") { _, _ -> onCancel() }.show()
    }

    fun askAdmin(a: Activity, onOk: () -> Unit, onCancel: () -> Unit = {}) {
        passDialog(a, "Admin passcode", {
            if (Store.checkAdmin(a, it)) onOk() else { toast(a, "Wrong passcode"); onCancel() }
        }, onCancel)
    }
}
